#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    string cities[] = {"Karachi", "Lahore", "Islamabad", "Quetta"};
    string days[] = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
    int temps[4][7] = {
        {32, 34, 31, 29, 33, 35, 36},
        {25, 27, 26, 24, 28, 29, 30},
        {18, 20, 19, 17, 21, 22, 23},
        {15, 16, 14, 13, 17, 18, 19}
    };

    cout << "Temperature Data (in C):\n";
    cout << setw(12) << " ";
    for (int d = 0; d < 7; d++)
        cout << setw(4) << days[d];
    cout << endl;

    // (a) Display temperature table
    for (int i = 0; i < 4; i++) {
        cout << left << setw(10) << cities[i] << ":";
        for (int j = 0; j < 7; j++) {
            cout << right << setw(4) << temps[i][j];
        }
        cout << endl;
    }
    cout << endl;

    // (b) Find and display average temperature for each city
    cout << "City Averages:\n";
    double cityAvg[4];
    for (int i = 0; i < 4; i++) {
        int sum = 0;
        for (int j = 0; j < 7; j++) sum += temps[i][j];
        cityAvg[i] = sum / 7.0;
        cout << fixed << setprecision(2);
        cout << cities[i] << ": " << cityAvg[i] << "C" << endl;
    }
    cout << endl;

    // (c) Find the hottest day overall (which city and which day)
    int maxTemp = temps[0][0];
    int hotCity = 0, hotDay = 0;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 7; j++) {
            if (temps[i][j] > maxTemp) {
                maxTemp = temps[i][j];
                hotCity = i;
                hotDay = j;
            }
        }
    }
    cout << "Hottest day: " << cities[hotCity]
         << " on " << days[hotDay]
         << " (" << maxTemp << "C)" << endl << endl;

    // (d) Find which day had highest average temperature across all cities
    double highestDayAvg = 0.0;
    int bestDay = 0;
    for (int j = 0; j < 7; j++) {
        int sum = 0;
        for (int i = 0; i < 4; i++) sum += temps[i][j];
        double avg = sum / 4.0;
        if (avg > highestDayAvg) {
            highestDayAvg = avg;
            bestDay = j;
        }
    }

    cout << "Day with highest average: " << days[bestDay]
         << " (" << fixed << setprecision(2)
         << highestDayAvg << "C)" << endl;

    return 0;
}
