#include <iostream>
#include <iomanip>  // for fixed and setprecision
#include <string>
using namespace std;

int main() {
    string vehicleType, dayType;
    int hours;
    double fee = 0.0;

    cout << "Enter vehicle type (car/motorcycle/truck): ";
    cin >> vehicleType;
    cout << "Enter hours parked: ";
    cin >> hours;
    cout << "Enter day (weekday/weekend): ";
    cin >> dayType;

    // Calculate fee based on inputs
    if (dayType == "weekday") {
        if (vehicleType == "car") {
            if (hours <= 2)
                fee = hours * 300;
            else
                fee = 2 * 300 + (hours - 2) * 200;
        }
        else if (vehicleType == "motorcycle") {
            fee = hours * 200;
        }
        else if (vehicleType == "truck") {
            if (hours <= 3)
                fee = hours * 500;
            else
                fee = 3 * 500 + (hours - 3) * 400;
        }

        // Apply 10% discount if parked more than 8 hours
        if (hours > 8) {
            fee = fee * 0.9;
            cout << fixed << setprecision(2);
            cout << "\nTotal fee: Rs. " << fee << endl;
            cout << "(10% discount applied for 8+ hours on weekday)" << endl;
            return 0;
        }
    }
    else if (dayType == "weekend") {
        if (vehicleType == "car")
            fee = hours * 400;
        else if (vehicleType == "motorcycle")
            fee = hours * 200;
        else if (vehicleType == "truck")
            fee = hours * 600;
    }

    // Display final fee
    cout << fixed << setprecision(2);
    cout << "\nTotal fee: Rs. " << fee << endl;

    return 0;
}
